exports.PORT = 3000;
exports.DB_Connection_String = 'mongodb://127.0.0.1:27017/Gaimin-Team';
exports.JWT_Secret = 'HuuuuuuugeSecretalabala';
exports.AUTH_COOKIE_NAME = 'auth_jwt';