const mongoose = require('mongoose');

let animalSchema = new mongoose.Schema({
    name: {
        type: String,
        required: true
    },
    image: {
        type: String,
        required: true
    },
    price: {
        type: Number,
        required: true
    },
    description: {
        type: String,
        required: true
    },
    genre: {
        type: String,
        required: true
    },
    platform: {
        type: String,
        enum: ["PC", "Nintendo", "PS4", "PS5", "XBOX"],
        required: true
    },
    owner: {
        type: mongoose.Types.ObjectId,
        ref: 'User'
    },
    donation: [
        {
            type: mongoose.Types.ObjectId,
            ref: 'User',
        }
    ],

}, { timestamps: true });

animalSchema.method('getDonation', function () {
    return this.donation.map(x => x._id);
})

let Animals = mongoose.model('Animals', animalSchema);

module.exports = Animals;