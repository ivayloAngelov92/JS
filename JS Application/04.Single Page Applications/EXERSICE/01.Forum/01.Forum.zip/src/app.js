import { showHome } from './home.js';


document.getElementById('homeLink').addEventListener('click', showHome);

// Start application in Home view
showHome();