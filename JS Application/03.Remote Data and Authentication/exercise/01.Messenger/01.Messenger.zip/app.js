// function attachEvents() {

//     document.querySelector("#refresh").addEventListener("click", displayComments); // Взимаме бутона за рефреш и добавяме слушател
//     document.querySelector("#submit").addEventListener("click", addComment);    // Взимаме бутона за submit и добавяме слушател 
// }
// let url = "http://localhost:3030/jsonstore/messenger";  // В променлива си взимаме адреса, за заявките 

// function addComment() {
//     let authorName = document.querySelector('[name="author"]');     // Намираме полето за името на автора 
//     let content = document.querySelector('[name="content"]');       // Намираме полето за съдържанието на съобщението

//     if (!authorName.value || !content.value )return       // Ако някое от двете е празно ;                                                     // Прекъсваме функцията 


//     fetch(url, {                                                // Фечваме заявка към адреса, като втори параметър даваме обект 
//         method: "POST",                                         // метода на заявката 
//         headers: {                                              // хедърите 
//             "Content-Type": "application/json",
//         },
//         body: JSON.stringify({                                  // Бодито е задължително JSON.stringify и подаваме обекта 
//             author: authorName.value.trim(),                    // Автора с въведенето в полето с изрязани спейсове 
//             content: content.value.trim(),                      // Съдържанието с въведенето в полето с изрязани спейсове 
//         }),
//     })
//         .then((response) => {                                  // Получаваме респонса 
//             if (!response.ok)    throw new Error("Error");                    // Ако не е наред 
//             return response.json();                             // Иначе връщаме респонса 
//         })
//         .catch((error) => alert(error.message));                        // Хвърляме грешка ако намерим някъде 

//                                      // Всеки път когато добавим коментар, показваме съобщенията 
// }
// function displayComments() {
//     fetch(url)                              // Фечваме заявка към адреса 
//         .then((response) => {               // Резолваме промиса на хедъра и получаваме респонс
//             if (!response.ok) throw new Error("Error")    // Ако респонса не е наред 
//             return response.json();         // Иначе връщаме респонса прекаран през json()
//         })
//         .then((data) => {                   // Резолваме промиса на бодито и получаваме данните 
//             let textArea = document.getElementById("messages");     // Намираме полето за съобщенията 
//             let comments = [];                                      // Правим празен масив за коментарите 
//             Object.values(data).forEach((user) =>                   // От получения обект взимаме валютата и минаваме по всеки 
//                 comments.push(`${user.author}: ${user.content}`)    // Към масива добавяме името на човека и съдържанието на съобщението 
//             );
//             textArea.value = comments.join("\n");                   // полето за съобщенията го сетваме да е масива с коментарите и всеки коментар да е на нов ред 
//         })
//         .catch((error) => alert(error.message));                    // Ако има грешка я показваме 
// }
// attachEvents();


function attachEvents() {
    document.getElementById('refresh').addEventListener('click', displayComments)
    document.getElementById('submit').addEventListener('click', addComment)
}
let url = "http://localhost:3030/jsonstore/messenger"

async function addComment() {
    let authorName = document.getElementsByName('author')[0]
    let content = document.getElementsByName('content')[0]

    if (!authorName.value || !content.value) return
    try {
        let response = await fetch(url, {
            method: 'POST',
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({
                author: authorName.value.trim(),
                content: content.value.trim()
            })
        })
        if (!response.ok) throw new Error('Error')
    } catch (err) { alert(err.message) }
}

async function displayComments(){
    try{
        let response=await fetch(url)
        if(!response.ok) throw new Error('Error')
        let data=await response.json()
        let comments=[]
        Object.values(data).forEach((user)=>{
            comments.push(`${user.author}: ${user.content}`)
        })
        document.getElementById("messages").textContent=comments.join('\n')
    }catch(err){alert(err.message)}
}
attachEvents();