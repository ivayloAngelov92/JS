export async function catalogView(ctx) {
    console.log( 'catalogView');
}
