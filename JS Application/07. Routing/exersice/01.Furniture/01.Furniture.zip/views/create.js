export async function createView(ctx) {
    console.log( 'catalogView');
}