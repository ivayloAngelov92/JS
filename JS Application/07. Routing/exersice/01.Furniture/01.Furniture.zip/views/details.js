export async function detailsView(ctx) {
    console.log( 'catalogView');
}