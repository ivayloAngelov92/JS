export async function myFurnitureView(ctx) {
    console.log( 'catalogView');
}