export async function loginView(ctx) {
    console.log( 'catalogView');
}