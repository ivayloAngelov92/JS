import { catalogView } from './views/catalog.js';
import { createView } from './views/create.js';
import { detailsView } from './views/details.js';
import { editView } from './views/edit.js';
import { loginView } from './views/login.js';
import { logoutView } from './views/logout.js';
import { myFurnitureView } from './views/myFurniture.js';
import { registerView } from './views/register.js';
import page from './node_modules/page/page.mjs';

export function updateNav() {
    let userNav = document.getElementById('user');
    let guestNav = document.getElementById('guest');
    if (sessionStorage.getItem('userData')==null) {
        userNav.style.display = 'none';
        guestNav.style.display = 'inline-block';
    }else{
        userNav.style.display = 'inline-block';
        guestNav.style.display = 'none';
    }
}
//start the page
updateNav()
document.getElementById('logoutBtn').addEventListener('click', logoutView);

page('/', catalogView)
page('/create', createView)
page('/login', loginView)
page('/register', registerView)
page('/details/:id', detailsView)
page('/edit/:id', editView)
page('/myPublications', myFurnitureView)

page.start()