async function getInfo() {
    let id = document.getElementById('stopId')
    let url = `http://localhost:3030/jsonstore/bus/businfo/${id.value}`
    let stopName = document.getElementById('stopName')
    let timeTable = document.getElementById('buses')

    try {
        timeTable.innerHTML = ''
        let response = await fetch(url)
        if (response.status !== 200) {
            stopName.textContent = 'Erorr'
        }
        let data = await response.json()
        stopName.textContent = data.name

        Object.entries(data.buses).forEach(b => {
            let li = document.createElement('li')
            li.textContent = `Bus ${b[0]} arrives in ${b[1]} minutes`
            timeTable.appendChild(li)
        })

    } catch (error) {
        stopName.textContent = 'Erorr'
    }

}